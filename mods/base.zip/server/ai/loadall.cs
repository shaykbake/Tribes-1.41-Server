rundir( "server/ai/" );
run( "ai" );