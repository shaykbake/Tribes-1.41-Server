exec( "server/game" );
exec( "server/game/towerswitch" );
exec( "server/game/staticshapes" );
exec( "server/game/events/stats-default" );