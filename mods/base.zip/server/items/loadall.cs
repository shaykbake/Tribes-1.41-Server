// do stuff that defines datablocks we need for items
rundir( "server/items/" );
run("damagetypes");
run("shockwave");
run("debris");
run("item");
run("marker");
run("nextweapon");


// turrets before weapons because elf/rocket define some datablocks/damagetypes weapons need
rundir( "server/items/turrets/" );
run("deployableturret");
run("elfturret");
run("indoorturret");
run("mortarturret");
run("plasmaturret");
run("rocketturret");
run("turret");


// now do weapons so they can define their damage types
rundir( "server/items/weapons/" );
run("blaster");
run("chaingun");
run("plasmagun");
run("grenadelauncher");
run("mortar");
run("disclauncher");
run("laserrifle");
run("targetinglaser");
run("elf");
run("repairgun");


// mine damage type
rundir( "server/items/misc/" );
run("repairkit");
run("mine");
run("grenade");
run("beacon");
run("flag");
run("repairpatch");


// now items not defining damage types, but referencing them
rundir( "server/items/armors/" );
run("armordamageskins");
run("lightarmor");
run("mediumarmor");
run("heavyarmor");


rundir( "server/items/packs/" );
run("energypack");
run("repairpack");
run("shieldpack");
run("sensorjammerpack");
run("ammopack");

run("deployableinv");
run("deployableammo");
run("motionsensorpack");
run("pulsesensorpack");
run("deployablesensorjammerpack");
run("camerapack");
run("turretpack");


rundir( "server/items/sensors/" );
run("sensor");
run("deployablemotionsensor");
run("deployablepulsesensor");
run("deployablesensor");
run("deployablesensorjammer");


rundir( "server/items/stations/" );
run("station");
run("vehiclestation");
run("ammostation");
run("commandstation");
run("deployablestation");
run("inventorystation");
run("remoteammostation");
run("remoteinventorystation");


rundir( "server/items/vehicles/" );
run("vehicle");
run("scout");
run("lpc");
run("hpc");


rundir( "server/items/" );
run("moveable");
run("staticshape");
run("trigger");
