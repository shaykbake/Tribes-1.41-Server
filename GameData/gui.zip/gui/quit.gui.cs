//--- export object begin ---//
instant SimGui::Control "quitGui" {
	position = "0 0";
	extent = "640 480";
	horizSizing = "center";
	vertSizing = "top";
	consoleVariable = "";
	consoleCommand = "";
	altConsoleCommand = "";
	deleteOnLoseContent = "True";
	ownObjects = "True";
	opaque = "True";
	fillColor = "0 0 0";
	selectFillColor = "0 0 0";
	ghostFillColor = "0 0 0";
	border = "False";
	borderColor = "0 0 0";
	selectBorderColor = "0 0 0";
	ghostBorderColor = "0 0 0";
	visible = "True";
	tag = "";
};
//--- export object end ---//
