//--- export object begin ---//
instant SimGui::BitmapCtrl "emptyGui" {
	position = "0 0";
	extent = "640 480";
	horizSizing = "right";
	vertSizing = "bottom";
	consoleVariable = "";
	consoleCommand = "";
	altConsoleCommand = "";
	deleteOnLoseContent = "True";
	ownObjects = "True";
	opaque = "False";
	fillColor = "0 0 0";
	selectFillColor = "0 0 0";
	ghostFillColor = "0 0 0.003922";
	border = "False";
	borderColor = "0 0 0";
	selectBorderColor = "0.772549 0.831373 0.843137";
	ghostBorderColor = "0 0 0";
	visible = "True";
	tag = "";
	active = "False";
	messageTag = "";
	bmpTag = "";
	transparent = "False";
};
//--- export object end ---//
