// legacy objectives.cs support
exec( "server/game" );
exec( "server/game/towerswitch" );
exec( "server/game/flag-original" );
exec( "server/game/events/stats-default" );