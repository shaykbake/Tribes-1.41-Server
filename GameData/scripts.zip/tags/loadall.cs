rundir( "Tags/" );
run( "commonEditor.strings" );
run( "editor.strings" );
run( "darkstar.strings" );
run( "fear.strings" );
run( "help.strings" );