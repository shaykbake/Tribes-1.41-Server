exec( "server/game" );
exec( "server/game/towerswitch" );
exec( "server/game/flag-ctf" );
exec( "server/game/events/stats-ctf" );