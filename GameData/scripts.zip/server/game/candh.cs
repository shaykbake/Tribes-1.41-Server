exec( "server/game" );
exec( "server/game/towerswitch" );
exec( "server/game/events/stats-default" );